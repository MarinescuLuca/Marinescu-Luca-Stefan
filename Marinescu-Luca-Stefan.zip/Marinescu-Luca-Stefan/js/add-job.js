// Logica specifică pentru add-job.html
window.addEventListener('DOMContentLoaded', () => {
    const username = localStorage.getItem("username_curent");
    if (!username) {
        alert("Trebuie să fii autentificat pentru a adăuga un job!");
        window.location.href = "login.html";
        return;
    }

    const form = document.getElementById("add-job-form");
    if (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();

            const title = document.getElementById("title").value.trim();
            const company = document.getElementById("company").value.trim();
            const location = document.getElementById("location").value.trim();
            const address = document.getElementById("address").value.trim();
            const phone = document.getElementById("phone").value.trim();
            const image = document.getElementById("image").value.trim();
            const description = document.getElementById("description").value.trim();

            if (!title || !company || !location || !address || !phone || !image || !description) {
                alert("Completează toate câmpurile, inclusiv adresa și telefonul!");
                return;
            }

            let jobs = JSON.parse(localStorage.getItem("jobs")) || [];
            const newJob = {
                id: Date.now(),
                title,
                company,
                location,
                address,
                phone,
                image,
                description,
                addedBy: username
            };

            jobs.push(newJob);
            localStorage.setItem("jobs", JSON.stringify(jobs));

            alert("✅ Job adăugat cu succes!");
            window.location.href = "index.html";
        });
    }
});