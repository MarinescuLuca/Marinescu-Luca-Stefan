// Logica specifică pentru index.html

// Variabilele și funcțiile trebuie definite aici
const username = localStorage.getItem("username_curent");

const defaultJobs = [
    { id: 1, title: "Programator Front-End", company: "WebDev Solutions", location: "București", address: "B-dul Unirii Nr. 5", phone: "0745 123 456", image: "programator.jpg", description: "Căutăm un front-end developer pasionat de React și UI modern." },
    { id: 2, title: "Vânzător Magazin", company: "Mega Retail", location: "Cluj-Napoca", address: "Str. Principală 10", phone: "0750 987 654", image: "vanzator.jpg", description: "Angajăm vânzători cu experiență în retail alimentar." },
    { id: 3, title: "Șofer Livrări", company: "FastDelivery", location: "Iași", address: "Calea Chișinăului 3", phone: "0733 444 555", image: "livrari.jpg", description: "Căutăm șoferi responsabili pentru livrări rapide în oraș." },
    { id: 4, title: "Electrician", company: "ElectroServ", location: "Constanța", address: "Bd. Tomis 200", phone: "0760 111 222", image: "electrician.jpg", description: "Post disponibil pentru electrician cu experiență în instalații industriale." },
    { id: 5, title: "Designer Grafic", company: "Creative Studio", location: "Timișoara", address: "Piața Victoriei 1", phone: "0720 777 888", image: "design.jpg", description: "Căutăm un designer creativ pentru proiecte publicitare." }
];

function getAllJobs() {
    const savedJobs = JSON.parse(localStorage.getItem("jobs")) || [];
    return [...defaultJobs, ...savedJobs];
}

function updateAuthButtons() {
    const authButtonsDiv = document.getElementById("auth-buttons");
    if (!authButtonsDiv) return;
    authButtonsDiv.innerHTML = "";
    
    if (username) {
        authButtonsDiv.innerHTML = `
            <button id="profile-btn" class="details-btn" onclick="window.location.href='profile.html'">
                Profilul meu (${username})
            </button>
            <button id="add-job-btn" class="details-btn" onclick="window.location.href='add-job.html'">
                Adaugă Job
            </button>
            <button id="logout-btn" onclick="logout()">
                Deconectează-te
            </button>
        `;
    } else {
        authButtonsDiv.innerHTML = `
            <button id="login-btn" class="details-btn" onclick="window.location.href='login.html'">
                Login
            </button>
            <button id="register-btn" class="details-btn" onclick="window.location.href='register.html'">
                Înregistrare
            </button>
        `;
    }
}

function displayJobs(jobsToDisplay) {
    const jobList = document.getElementById("job-list");
    if (!jobList) return;
    jobList.innerHTML = "";

    if (jobsToDisplay.length === 0) {
        jobList.innerHTML = "<p style='text-align:center; width:100%;'>Nu s-au găsit joburi.</p>";
        return;
    }

    jobsToDisplay.forEach(job => {
        const jobCard = document.createElement("div");
        jobCard.className = "job-card";
        jobCard.innerHTML = `
            <img src="${job.image || 'default.jpg'}" alt="Imagine pentru ${job.title}" class="job-card-img">
            <h3>${job.title}</h3>
            <p><strong>Companie:</strong> ${job.company}</p>
            <p><strong>Locație:</strong> ${job.location}</p>
            <p><strong>Adresă:</strong> ${job.address || 'N/A'}</p> 
            <a href="job-details.html?id=${job.id}" class="details-btn">Vezi Detalii</a>
        `;
        jobList.appendChild(jobCard);
    });
}

function searchJobs() {
    const searchTerm = document.getElementById("search-input").value.toLowerCase().trim();
    const allJobs = getAllJobs();

    const filteredJobs = allJobs.filter(job =>
        job.title.toLowerCase().includes(searchTerm) ||
        job.company.toLowerCase().includes(searchTerm) ||
        job.location.toLowerCase().includes(searchTerm) ||
        job.description.toLowerCase().includes(searchTerm)
    );

    displayJobs(filteredJobs);
}

function filterByLocation(location) {
    document.getElementById("search-input").value = location;
    searchJobs();
}

// Evenimentul principal care rulează la încărcarea paginii
window.addEventListener('DOMContentLoaded', () => {
    displayJobs(getAllJobs());
    updateAuthButtons();

    const searchInput = document.getElementById("search-input");
    const searchButton = document.querySelector(".search-container button");

    if (searchInput) {
        searchInput.addEventListener("keypress", function(event) {
            if (event.key === "Enter") {
                event.preventDefault();
                searchJobs();
            }
        });
    }
    
    if (searchButton) {
        searchButton.onclick = searchJobs; // Asociază funcția la click pe buton
    }

    // Facem link-urile din aside funcționale
    window.filterByLocation = filterByLocation;
});