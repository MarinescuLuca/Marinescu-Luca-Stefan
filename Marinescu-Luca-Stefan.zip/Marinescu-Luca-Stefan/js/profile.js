// Logica specifică pentru profile.html

// Funcția de retragere trebuie să fie globală pentru a fi găsită de 'onclick'
function removeApplication(jobId) {
    if (!confirm("Ești sigur că vrei să retragi aplicația pentru acest job?")) {
        return;
    }
    
    const username = localStorage.getItem("username_curent");
    let currentApplications = JSON.parse(localStorage.getItem("applications")) || [];
    const indexToRemove = currentApplications.findIndex(
        a => a.username === username && a.jobId === jobId
    );

    if (indexToRemove > -1) {
        currentApplications.splice(indexToRemove, 1);
    }
    localStorage.setItem("applications", JSON.stringify(currentApplications));

    alert("Aplicația a fost retrasă cu succes!");
    window.location.reload();
}

window.addEventListener('DOMContentLoaded', () => {
    const username = localStorage.getItem("username_curent");
    if (!username) {
        alert("🔒 Trebuie să fii autentificat pentru a vedea profilul!");
        window.location.href = "login.html";
        return; // Oprește execuția scriptului dacă nu e logat
    }

    document.getElementById("welcome").textContent = "Bun venit, " + username + "!";

    // Logica CV
    const usersCV = JSON.parse(localStorage.getItem("usersCV")) || {};
    const cvInfo = document.getElementById("cv-info");
    if (usersCV[username]) {
        const cv = usersCV[username];
        cvInfo.innerHTML = `
            <p>Nume fișier: ${cv.name}</p>
            <a href="${cv.data}" download="${cv.name}" class="apply-btn">Descarcă CV</a>
        `;
    }

    // Logica Afișare Aplicații
    const applications = JSON.parse(localStorage.getItem("applications")) || [];
    const defaultJobs = [ // Lista de joburi e necesară pentru a afișa detaliile
        { id: 1, title: "Programator Front-End", company: "WebDev Solutions", location: "București" },
        { id: 2, title: "Vânzător Magazin", company: "Mega Retail", location: "Cluj-Napoca" },
        { id: 3, title: "Șofer Livrări", company: "FastDelivery", location: "Iași" },
        { id: 4, title: "Electrician", company: "ElectroServ", location: "Constanța" },
        { id: 5, title: "Designer Grafic", company: "Creative Studio", location: "Timișoara" }
    ];
    const allJobs = defaultJobs.concat(JSON.parse(localStorage.getItem("jobs")) || []);

    const userApplications = applications.filter(a => a.username === username);
    const applicationsList = document.getElementById("applications-list");

    if (userApplications.length === 0) {
        applicationsList.innerHTML = "<li>Nu ai aplicat la niciun job încă.</li>";
    } else {
        userApplications.forEach(a => {
            const job = allJobs.find(j => j.id == a.jobId);
            if (job) {
                const li = document.createElement("li");
                li.innerHTML = `
                    <span style="flex-grow: 1;">
                        <strong>${job.title}</strong> - ${job.company}, ${job.location}
                    </span>
                    <a href="job-details.html?id=${job.id}" class="details-btn">Vezi detalii</a>
                    <button class="apply-btn" onclick="removeApplication(${job.id})">
                        Retrage aplicația
                    </button>
                `;
                applicationsList.appendChild(li);
            }
        });
    }
});