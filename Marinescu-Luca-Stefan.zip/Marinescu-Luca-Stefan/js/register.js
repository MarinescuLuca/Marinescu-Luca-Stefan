// Logica specifică pentru register.html
window.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById("register-form");

    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const username = document.getElementById("new-username").value.trim();
            const password = document.getElementById("new-password").value;
            const confirmPassword = document.getElementById("confirm-password").value;

            if (password !== confirmPassword) {
                alert("❌ Parolele nu se potrivesc!");
                return;
            }

            let users = JSON.parse(localStorage.getItem("users")) || {};

            if (users[username]) {
                alert("⚠️ Username-ul există deja! Alege altul.");
                return;
            }

            users[username] = { password: password };
            localStorage.setItem("users", JSON.stringify(users));

            localStorage.setItem("username_curent", username);

            alert("✅ Cont creat cu succes! Acum poți încărca CV-ul tău.");
            window.location.href = "upload-cv.html";
        });
    }
});