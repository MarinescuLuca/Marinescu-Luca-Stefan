// Logica specifică pentru login.html
window.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById("login-form");

    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value;

            let users = JSON.parse(localStorage.getItem("users")) || {};

            if (users[username] && users[username].password === password) {
                localStorage.setItem("username_curent", username);
                alert("✅ Autentificare reușită!");
                window.location.href = "index.html";
            } else {
                alert("❌ Username sau parolă incorecte!");
            }
        });
    }
});