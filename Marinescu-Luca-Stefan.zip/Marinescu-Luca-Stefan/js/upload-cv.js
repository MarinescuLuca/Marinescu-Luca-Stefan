// Logica specifică pentru upload-cv.html
window.addEventListener('DOMContentLoaded', () => {
    const username = localStorage.getItem("username_curent");
    if (!username) {
        alert("Trebuie să fii autentificat pentru a încărca un CV!");
        window.location.href = "login.html";
        return;
    }

    const cvForm = document.getElementById("cv-form");
    if (cvForm) {
        cvForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const fileInput = document.getElementById("cv-file");
            const file = fileInput.files[0];

            if (!file) {
                alert("Selectează un fișier!");
                return;
            }

            const reader = new FileReader();
            reader.onload = function () {
                let usersCV = JSON.parse(localStorage.getItem("usersCV")) || {};
                usersCV[username] = { name: file.name, data: reader.result };
                localStorage.setItem("usersCV", JSON.stringify(usersCV));

                alert("✅ CV-ul a fost încărcat cu succes!");
                window.location.href = "profile.html";
            };
            reader.readAsDataURL(file);
        });
    }
});