// Logica specifică pentru job-details.html

// Funcția de aplicare trebuie să fie globală pentru 'onclick'
function applyForJob() {
    const username = localStorage.getItem("username_curent");
    if (!username) {
        alert("🔒 Trebuie să fii autentificat pentru a aplica la un job!");
        window.location.href = "login.html";
        return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    const jobId = parseInt(urlParams.get("id"));
    let applications = JSON.parse(localStorage.getItem("applications")) || [];
    
    const dejaAplicat = applications.find(a => a.username === username && a.jobId === jobId);

    if (dejaAplicat) {
        alert("ℹ️ Ai aplicat deja la acest job.");
    } else {
        applications.push({ username: username, jobId: jobId });
        localStorage.setItem("applications", JSON.stringify(applications));
        alert("✅ Aplicație trimisă cu succes!");
        
        const applyBtn = document.getElementById("apply-btn");
        applyBtn.textContent = "Ai aplicat";
        applyBtn.disabled = true;
    }
}

window.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const jobId = parseInt(urlParams.get("id"));
    const username = localStorage.getItem("username_curent");

    const defaultJobs = [
        { id: 1, title: "Programator Front-End", company: "WebDev Solutions", location: "București", address: "B-dul Unirii Nr. 5", phone: "0745 123 456", image: "programator.jpg", description: "Căutăm un front-end developer pasionat de React și UI modern." },
        { id: 2, title: "Vânzător Magazin", company: "Mega Retail", location: "Cluj-Napoca", address: "Str. Principală 10", phone: "0750 987 654", image: "vanzator.jpg", description: "Angajăm vânzători cu experiență în retail alimentar." },
        { id: 3, title: "Șofer Livrări", company: "FastDelivery", location: "Iași", address: "Calea Chișinăului 3", phone: "0733 444 555", image: "livrari.jpg", description: "Căutăm șoferi responsabili pentru livrări rapide în oraș." },
        { id: 4, title: "Electrician", company: "ElectroServ", location: "Constanța", address: "Bd. Tomis 200", phone: "0760 111 222", image: "electrician.jpg", description: "Post disponibil pentru electrician cu experiență în instalații industriale." },
        { id: 5, title: "Designer Grafic", company: "Creative Studio", location: "Timișoara", address: "Piața Victoriei 1", phone: "0720 777 888", image: "design.jpg", description: "Căutăm un designer creativ pentru proiecte publicitare." }
    ];

    const savedJobs = JSON.parse(localStorage.getItem("jobs")) || [];
    const allJobs = [...defaultJobs, ...savedJobs];
    const job = allJobs.find(j => j.id === jobId);

    const detailsDiv = document.getElementById("job-details");

    if (job) {
        detailsDiv.innerHTML = `
            <img src="${job.image}" alt="Imagine pentru ${job.title}" class="job-detail-img">
            <h2>${job.title}</h2>
            <p><strong>Companie:</strong> ${job.company}</p>
            <p><strong>Locație:</strong> ${job.location}</p>
            <div style="margin: 20px 0; padding: 15px; border: 1px solid #eee; border-radius: 8px; background-color: #f9f9f9;">
                <p><strong>Adresă de Contact:</strong> ${job.address || 'N/A'}</p>
                <p><strong>Telefon:</strong> <a href="tel:${job.phone}" style="color: var(--color-secondary); text-decoration: none;">${job.phone || 'N/A'}</a></p>
            </div>
            <p><strong>Descriere:</strong> ${job.description}</p>
            <button class="apply-btn" id="apply-btn" onclick="applyForJob()">
                Aplică Acum
            </button>
        `;
    } else {
        detailsDiv.innerHTML = "<p>⚠️ Jobul nu a fost găsit!</p>";
    }

    // Verificăm starea butonului la încărcarea paginii
    if (username) {
        let applications = JSON.parse(localStorage.getItem("applications")) || [];
        const dejaAplicat = applications.find(a => a.username === username && a.jobId === jobId);
        if (dejaAplicat) {
            const applyBtn = document.getElementById("apply-btn");
            if (applyBtn) {
                applyBtn.textContent = "Ai aplicat";
                applyBtn.disabled = true;
            }
        }
    }
});