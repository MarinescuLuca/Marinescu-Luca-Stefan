<?php
// Redirect to public folder
header('Location: /public/index.html');
exit;
?>
