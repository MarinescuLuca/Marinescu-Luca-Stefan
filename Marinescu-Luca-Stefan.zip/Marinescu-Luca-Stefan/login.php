<?php
// Conectare la baza de date
$servername = "localhost";
$username = "root"; // utilizator MySQL
$password = ""; // parola MySQL
$dbname = "site_db"; // baza de date

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificăm conexiunea
if ($conn->connect_error) {
    die("Conectarea la baza de date a eșuat: " . $conn->connect_error);
}

// Verificăm dacă formularul a fost trimis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Preluăm datele din formular
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prevenim SQL Injection
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);

    // Căutăm utilizatorul în baza de date
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Utilizatorul există, verificăm parola
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Parola este corectă, începem sesiunea
            session_start();
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            header('Location: welcome.php'); // Redirecționare către pagina de succes
        } else {
            echo "Parola incorectă!";
        }
    } else {
        echo "Utilizatorul nu a fost găsit!";
    }
}
?>
