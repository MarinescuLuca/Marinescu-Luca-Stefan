const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, '../public')));

const db = mysql.createPool({
    host: 'db',
    user: 'user',
    password: 'password',
    database: 'jobfinder_db'
});

db.getConnection((err, connection) => {
    if (err) {
        console.error('❌ Eroare conectare la Baza de Date:', err);
    } else {
        console.log('✅ Conectat cu succes la MySQL!');
        connection.release();
    }
});

app.get('/api/jobs', (req, res) => {
    const sql = 'SELECT * FROM jobs ORDER BY created_at DESC';
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

app.post('/api/jobs', (req, res) => {
    const { title, company, location, address, phone, image, description, addedBy } = req.body;
    const sql = 'INSERT INTO jobs (title, company, location, address, phone, image, description, added_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    
    db.query(sql, [title, company, location, address, phone, image, description, addedBy], (err, result) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Job adaugat cu succes!', id: result.insertId });
    });
});

app.post('/api/register', (req, res) => {
    const { username, password } = req.body;
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) return res.status(500).json(err);
        if (results.length > 0) return res.status(400).json({ message: 'Userul exista deja' });

        db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], (err, result) => {
            if (err) return res.status(500).json(err);
            res.json({ success: true });
        });
    });
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    db.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, results) => {
        if (err) return res.status(500).json(err);
        if (results.length > 0) {
            res.json({ success: true, username: username });
        } else {
            res.status(401).json({ success: false, message: 'Date incorecte' });
        }
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 Serverul ruleaza pe http://localhost:${PORT}`);
});