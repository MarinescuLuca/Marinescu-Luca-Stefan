/* === LOGICĂ COMUNĂ PENTRU TOT SITE-UL === */

/**
 * Funcția de Deconectare
 * Șterge utilizatorul curent și trimite la pagina de login.
 */
function logout() {
    localStorage.removeItem("username_curent");
    // Trimitem la pagina de login
    window.location.href = "login.html";
}


/**
 * Logica pentru butonul "Mergi Sus"
 * Apare la scroll și face scroll lin spre sus la click.
 */
document.addEventListener('DOMContentLoaded', function() {
    const backToTopButton = document.getElementById('back-to-top');
    
    // Verificăm dacă butonul există pe această pagină
    if (backToTopButton) {
        
        // Funcția care afișează/ascunde butonul
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) { // Apare după 300px
                backToTopButton.style.display = 'block';
            } else {
                backToTopButton.style.display = 'none';
            }
        });

        // Funcția care face scroll lin la click
        backToTopButton.addEventListener('click', function(e) {
            e.preventDefault(); // Oprește comportamentul default al link-ului (#)
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Ascunde butonul la încărcarea paginii
        backToTopButton.style.display = 'none';
    }
});