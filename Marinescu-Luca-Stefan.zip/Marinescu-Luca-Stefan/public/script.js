﻿/* === LOGICA COMUNA PENTRU TOT SITE-UL === */

/**
 * Functia de Deconectare
 * Sterge utilizatorul curent si trimite la pagina de login.
 */
async function logout() {
    try {
        await apiClient.logout();
    } catch (error) {
        console.log('Logout error:', error);
    }
    localStorage.removeItem("user_session");
    window.location.href = "login.html";
}


/**
 * Logica pentru butonul "Mergi Sus"
 * Apare la scroll si face scroll lin spre sus la click.
 */
document.addEventListener('DOMContentLoaded', function() {
    const backToTopButton = document.getElementById('back-to-top');
    
    // Verificam daca butonul exista pe aceasta pagina
    if (backToTopButton) {
        
        // Functia care afiseaza/ascunde butonul
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) { // Apare dupa 300px
                backToTopButton.style.display = 'block';
            } else {
                backToTopButton.style.display = 'none';
            }
        });

        // Functia care face scroll lin la click
        backToTopButton.addEventListener('click', function(e) {
            e.preventDefault(); // Opreste comportamentul default al link-ului (#)
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Ascunde butonul la incarcarea paginii
        backToTopButton.style.display = 'none';
    }
});
