﻿document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById("add-job-form");
    if (form) {
        form.addEventListener("submit", async function (e) {
            e.preventDefault();

            const title = document.getElementById("title").value.trim();
            const company = document.getElementById("company").value.trim();
            const location = document.getElementById("location").value.trim();
            const address = document.getElementById("address").value.trim();
            const phone = document.getElementById("phone").value.trim();
            const image = document.getElementById("image").value.trim();
            const description = document.getElementById("description").value.trim();
            const salary_min = document.getElementById("salary_min") ? parseInt(document.getElementById("salary_min").value) || null : null;
            const salary_max = document.getElementById("salary_max") ? parseInt(document.getElementById("salary_max").value) || null : null;
            const job_type = document.getElementById("job_type").value;

            if (!title || !company || !location || !description) {
                alert("Completeaza campurile obligatorii!");
                return;
            }

            try {
                const data = await apiClient.createJob({
                    title, company, location, address, phone, image, description,
                    salary_min, salary_max, job_type
                });

                alert("✅ Job adaugat cu succes!");
                window.location.href = "my-jobs.html";
            } catch (error) {
                alert("Eroare: " + error.message);
            }
        });
    } else {
        console.error('Form with id add-job-form not found');
    }
});
