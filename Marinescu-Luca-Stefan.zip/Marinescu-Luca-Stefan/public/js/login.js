﻿// Logica specifica pentru login.html
window.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById("login-form");

    if (loginForm) {
        loginForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value;

            try {
                const response = await apiClient.login(username, password);
                if (response.success) {
                    localStorage.setItem("user_session", JSON.stringify(response.user));
                    alert("✅ Autentificare reusita!");
                    window.location.href = "index.html";
                }
            } catch (error) {
                alert("❌ " + error.message);
            }
        });
    }
});
