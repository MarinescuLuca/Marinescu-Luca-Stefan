﻿// Logica specifica pentru job-details.html

// Functia de aplicare trebuie sa fie globala pentru 'onclick'
async function applyForJob(jobId) {
    try {
        const session = await apiClient.checkSession();
        if (!session.user) {
            alert("🔐 Trebuie sa fii autentificat pentru a aplica la un job!");
            window.location.href = "login.html";
            return;
        }

        await apiClient.applyForJob(jobId);
        alert("✅ Aplicatie trimisa cu succes!");
        
        const applyBtn = document.getElementById("apply-btn");
        if (applyBtn) {
            applyBtn.textContent = "Ai aplicat";
            applyBtn.disabled = true;
        }
    } catch (error) {
        alert("❌ " + error.message);
    }
}

window.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const jobId = parseInt(urlParams.get("id"));
    const detailsDiv = document.getElementById("job-detail");

    if (!jobId || Number.isNaN(jobId)) {
        if (detailsDiv) {
            detailsDiv.innerHTML = "<p>ID job invalid. Te rog revino la lista si incearca din nou.</p>";
        }
        return;
    }

    try {
        const response = await apiClient.getJobById(jobId);
        let job = response.job;
        if (!job && response.jobs && Array.isArray(response.jobs)) {
            job = response.jobs.find(item => Number(item.id) === jobId);
        }

        if (job) {
            // Check user role
            let applyButtonHTML = '';
            let messageButtonHTML = '';
            let userRole = null;
            try {
                const session = await apiClient.checkSession();
                if (session.user && session.user.role === 'client') {
                    userRole = 'client';
                    applyButtonHTML = `<button class="apply-btn" id="apply-btn" onclick="applyForJob(${job.id})">Aplica Acum</button>`;
                    if (job.creator_username) {
                        messageButtonHTML = `<button class="details-btn" onclick="openMessage('${job.creator_username}')">Trimite mesaj creatorului</button>`;
                    }
                }
            } catch (e) {
                // User not logged in
            }

            const imageSrc = job.image && job.image.trim() ? job.image : 'logo-jobfinder.svg';
            detailsDiv.innerHTML = `
                <img src="${imageSrc}" alt="Imagine pentru ${job.title}" class="job-detail-img">
                <div class="job-detail-header">
                    <h2>${job.title}</h2>
                    <div class="job-detail-badges">
                        <span class="job-badge">Tip: ${job.job_type}</span>
                        ${job.salary_min ? `<span class="job-badge">Salariu: ${job.salary_min} - ${job.salary_max} RON</span>` : ''}
                    </div>
                </div>
                <div class="job-detail-grid">
                    <div class="job-detail-field">
                        <strong>Companie</strong>
                        <span>${job.company}</span>
                    </div>
                    <div class="job-detail-field">
                        <strong>Locatie</strong>
                        <span>${job.location}</span>
                    </div>
                    <div class="job-detail-field">
                        <strong>Adresa de Contact</strong>
                        <span>${job.address || 'N/A'}</span>
                    </div>
                    <div class="job-detail-field">
                        <strong>Telefon</strong>
                        <span>${job.phone ? `<a href="tel:${job.phone}" style="color: var(--color-secondary); text-decoration: none;">${job.phone}</a>` : 'N/A'}</span>
                    </div>
                </div>
                <div class="job-detail-desc">
                    <strong>Descriere</strong>
                    <p>${job.description || 'N/A'}</p>
                </div>
                <div style="display:flex; gap:12px; flex-wrap: wrap; margin-top: 16px;">
                    ${applyButtonHTML}
                    ${messageButtonHTML}
                </div>
            `;
        } else {
            detailsDiv.innerHTML = "<p>Jobul nu a fost gasit!</p>";
        }

        // Verifica daca user e logat si daca a aplicat deja
        try {
            const session = await apiClient.checkSession();
            if (session.user && session.user.role === 'client') {
                const apps = await apiClient.getApplications();
                const hasApplied = apps.applications && apps.applications.some(a => a.job_id === jobId);
                if (hasApplied) {
                    const applyBtn = document.getElementById("apply-btn");
                    if (applyBtn) {
                        applyBtn.textContent = "Ai aplicat";
                        applyBtn.disabled = true;
                    }
                }
            }
        } catch (e) {
            // User not logged in, ignore
        }
    } catch (error) {
        console.error('Eroare:', error);
        document.getElementById("job-detail").innerHTML = "<p>Eroare la incarcare detalii job: " + error.message + "</p>";
    }
});

function openMessage(username) {
    if (!username) return;
    window.location.href = `messages.html?with=${encodeURIComponent(username)}`;
}

