// ====== ADMIN PANEL LOGIC ======
let allUsers = [];

window.addEventListener('DOMContentLoaded', async () => {
    // Check if user is logged in and is admin
    try {
        const response = await apiClient.checkSession();
        if (!response.user || response.user.role !== 'admin') {
            alert('❌ Acces interzis! Doar adminii pot accesa aceasta pagina.');
            window.location.href = 'index.html';
            return;
        }
    } catch (error) {
        window.location.href = 'login.html';
        return;
    }

    // Load stats
    loadStats();
    // Load users
    loadUsers();
});

async function loadStats() {
    try {
        const data = await apiClient.getAdminStats();
        document.getElementById('stat-total-users').textContent = data.stats.total_users;
        document.getElementById('stat-admins').textContent = data.stats.admins;
        document.getElementById('stat-clients').textContent = data.stats.clients;
        document.getElementById('stat-jobs').textContent = data.stats.active_jobs;
    } catch (error) {
        console.error('Eroare la incarcare stats:', error);
    }
}

async function loadUsers() {
    try {
        const data = await apiClient.getUsers();
        allUsers = data.users;
        renderUsers(allUsers);
    } catch (error) {
        alert('❌ Eroare la incarcare useri: ' + error.message);
    }
}

function renderUsers(users) {
    const tbody = document.getElementById('users-list');
    tbody.innerHTML = '';

    users.forEach(user => {
        const row = document.createElement('tr');
        row.style.borderBottom = '1px solid #e2e8f0';
        row.innerHTML = `
            <td style="padding: 16px; color: #1e293b; font-weight: 500;">${user.username}</td>
            <td style="padding: 16px; color: #64748b;">${user.email || 'N/A'}</td>
            <td style="padding: 16px;">
                <span style="display: inline-block; padding: 6px 12px; border-radius: 8px; font-size: 0.85rem; font-weight: 600; ${
                    user.role === 'admin' 
                        ? 'background: #e0e7ff; color: #4f46e5;' 
                        : 'background: #dbeafe; color: #0284c7;'
                }">
                    ${user.role === 'admin' ? '⚙️ Admin' : '👤 Client'}
                </span>
            </td>
            <td style="padding: 16px; color: #64748b; font-size: 0.9rem;">${new Date(user.created_at).toLocaleDateString('ro-RO')}</td>
            <td style="padding: 16px; text-align: center;">
                <button class="details-btn" onclick="changeRole(${user.id}, '${user.role}')" style="margin-right: 8px; padding: 8px 12px; font-size: 0.85rem;">
                    ${user.role === 'admin' ? 'Face Client' : 'Face Admin'}
                </button>
                ${user.username !== 'admin' ? `<button class="apply-btn" onclick="deleteUserConfirm(${user.id}, '${user.username}')" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 8px 12px; font-size: 0.85rem;">Sterge</button>` : ''}
            </td>
        `;
        tbody.appendChild(row);
    });
}

function filterUsers() {
    const searchTerm = document.getElementById('search-users').value.toLowerCase();
    const filtered = allUsers.filter(user => 
        user.username.toLowerCase().includes(searchTerm) || 
        (user.email && user.email.toLowerCase().includes(searchTerm))
    );
    renderUsers(filtered);
}

async function changeRole(userId, currentRole) {
    const newRole = currentRole === 'admin' ? 'client' : 'admin';
    const confirm = window.confirm(`Schimba role-ul acestui user la: ${newRole}?`);
    
    if (!confirm) return;

    try {
        await apiClient.updateUserRole(userId, newRole);
        alert('✅ Role schimbat cu succes!');
        loadUsers();
        loadStats();
    } catch (error) {
        alert('❌ Eroare: ' + error.message);
    }
}

function deleteUserConfirm(userId, username) {
    const confirm = window.confirm(`Esti sigur ca vrei sa stergi userul "${username}"? Aceasta actiune nu poate fi anulata.`);
    
    if (!confirm) return;

    deleteUser(userId);
}

async function deleteUser(userId) {
    try {
        await apiClient.deleteUser(userId);
        alert('✅ User sters cu succes!');
        loadUsers();
        loadStats();
    } catch (error) {
        alert('❌ Eroare: ' + error.message);
    }
}

// Search on enter
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-users');
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                filterUsers();
            }
        });
    }
});
