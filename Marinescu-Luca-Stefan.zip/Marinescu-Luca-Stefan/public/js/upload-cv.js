﻿// Logica specifica pentru upload-cv.html
document.addEventListener('DOMContentLoaded', async () => {
    // Check session
    try {
        await apiClient.checkSession();
    } catch (e) {
        alert("Trebuie sa fii autentificat pentru a incarca un CV!");
        window.location.href = 'login.html';
        return;
    }

    const cvForm = document.getElementById("cv-form");
    if (cvForm) {
        cvForm.addEventListener("submit", async function (e) {
            e.preventDefault();
            const fileInput = document.getElementById("cv-file");
            const file = fileInput.files[0];

            if (!file) {
                alert("Selecteaza un fisier!");
                return;
            }

            try {
                const data = await apiClient.uploadCV(file);
                alert("✅ CV-ul a fost incarcat cu succes!");
                window.location.href = "profile.html";
            } catch (error) {
                console.error('Error:', error);
                alert("Eroare: " + error.message);
            }
        });
    }
});
