﻿// Logica specifica pentru profile.html

async function deleteCV(cvId) {
    if (!confirm("Esti sigur ca vrei sa stergi acest CV?")) return;
    try {
        await apiClient.deleteCV(cvId);
        alert("✅ CV sters cu succes!");
        window.location.reload();
    } catch (error) {
        alert("❌ " + error.message);
    }
}

async function removeApplication(applicationId) {
    if (!confirm("Esti sigur ca vrei sa retragi aceasta aplicatie?")) {
        return;
    }
    
    try {
        await apiClient.removeApplication(applicationId);
        alert("✅ Aplicatia a fost retractata cu succes!");
        window.location.reload();
    } catch (error) {
        alert("❌ " + error.message);
    }
}

window.addEventListener('DOMContentLoaded', async () => {
    try {
        const session = await apiClient.checkSession();
        if (!session.user) {
            alert("🔐 Trebuie sa fii autentificat pentru a vedea profilul!");
            window.location.href = "login.html";
            return;
        }

        document.getElementById("welcome").innerHTML = `Bun venit, <strong>${session.user.username}</strong>!`;

        // Load profile data
        const profile = await apiClient.getProfile();
        
        // Show stats
        const statsDiv = document.getElementById("stats");
        if (statsDiv) {
            statsDiv.innerHTML = `
                <p><strong>Aplicatii trimise:</strong> ${profile.stats.applications}</p>
                <p><strong>CV-uri incarcate:</strong> ${profile.stats.cvs}</p>
            `;
        }

        // Load CVs
        const cvSection = document.getElementById("cv-section");
        if (cvSection) {
            const cvs = await apiClient.getCVs();
            const cvList = document.getElementById("cv-list");
            if (cvs.cvs && cvs.cvs.length > 0) {
                cvList.innerHTML = cvs.cvs.map(cv => `
                    <div style="background: #f0f9ff; padding: 12px; border-radius: 8px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <strong>${cv.file_name}</strong><br>
                            <small style="color: #64748b;">${(cv.file_size / 1024).toFixed(2)} KB</small>
                        </div>
                        <button onclick="deleteCV(${cv.id})" class="apply-btn" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 8px 12px; font-size: 0.85rem;">Sterge</button>
                    </div>
                `).join('');
            } else {
                cvList.innerHTML = "<p style='color: #64748b;'>Nu ai inca incarcate CV-uri.</p>";
            }
        }

        // Load applications
        const applications = await apiClient.getApplications();
        const applicationsList = document.getElementById("applications-list");
        
        if (applications.applications && applications.applications.length > 0) {
            applicationsList.innerHTML = applications.applications.map(app => `
                <li>
                    <span style="flex-grow: 1;">
                        <strong>${app.title}</strong> - ${app.company}, ${app.location}
                    </span>
                    <a href="job-details.html?id=${app.job_id}" class="details-btn">Vezi detalii</a>
                    <button class="apply-btn" onclick="removeApplication(${app.id})" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);">
                        Retrage
                    </button>
                </li>
            `).join('');
        } else {
            applicationsList.innerHTML = "<li style='color: #64748b;'>Nu ai aplicat la niciun job inca.</li>";
        }

    } catch (error) {
        console.error(error);
        window.location.href = "login.html";
    }
});

