﻿// Logica specifica pentru index.html

// ====== VARIABILE GLOBALE ======
let allJobsData = [];

async function updateAuthButtons() {
    const authButtonsDiv = document.getElementById("auth-buttons");
    if (!authButtonsDiv) return;
    authButtonsDiv.innerHTML = "";
    
    try {
        const session = await apiClient.checkSession();
        if (session.user) {
            let adminLink = '';
            if (session.user.role === 'admin') {
                adminLink = '<button id="admin-btn" class="details-btn" onclick="window.location.href=\'admin.html\'" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">Panou Admin</button>';
            }
            let addJobButton = '';
            if (session.user.role === 'client') {
                addJobButton = '<button id="add-job-btn" class="details-btn" onclick="window.location.href=\'add-job.html\'">+ Adauga Job</button>';
            }
            authButtonsDiv.innerHTML = `
                <button id="profile-btn" class="details-btn" onclick="window.location.href='profile.html'">
                    Profilul meu (${session.user.username})
                </button>
                ${addJobButton}
                ${adminLink}
                <button id="logout-btn" onclick="logout()" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);">
                    Deconecteaza-te
                </button>
            `;
        } else {
            authButtonsDiv.innerHTML = `
                <button id="login-btn" class="details-btn" onclick="window.location.href='login.html'">
                    Login
                </button>
                <button id="register-btn" class="details-btn" onclick="window.location.href='register.html'">
                    Inregistrare
                </button>
            `;
        }
    } catch (error) {
        authButtonsDiv.innerHTML = `
            <button id="login-btn" class="details-btn" onclick="window.location.href='login.html'">
                Login
            </button>
            <button id="register-btn" class="details-btn" onclick="window.location.href='register.html'">
                Inregistrare
            </button>
        `;
    }
}

async function displayJobs(jobsToDisplay = null) {
    const jobList = document.getElementById("job-list");
    if (!jobList) return;
    jobList.innerHTML = "";

    try {
        const jobs = jobsToDisplay || allJobsData || [];
        
        if (jobs.length === 0) {
            jobList.innerHTML = "<p style='text-align:center; width:100%;'>Nu s-au gasit joburi.</p>";
            return;
        }

        jobs.forEach(job => {
            const jobCard = document.createElement("div");
            jobCard.className = "job-card";
            jobCard.innerHTML = `
                <img src="${job.image || 'logo-jobfinder.svg'}" alt="Imagine pentru ${job.title}" class="job-card-img">
                <div class="job-card-details">
                    <h3>${job.title}</h3>
                    <p><strong>💼 ${job.company}</strong></p>
                    <p>📍 ${job.location}</p>
                    <p><small>${job.description || ''}</small></p>
                    <div style="margin-top: 12px;">
                        <a href="job-details.html?id=${job.id}" class="details-btn">Vezi Detalii</a>
                    </div>
                </div>
            `;
            jobList.appendChild(jobCard);
        });
    } catch (error) {
        console.error('Eroare la incarcare joburi:', error);
        jobList.innerHTML = "<p style='text-align:center; width:100%; color:#ef4444;'>Eroare la incarcare joburi</p>";
    }
}

async function searchJobs() {
    const searchTerm = document.getElementById("search-input").value.toLowerCase().trim();

    try {
        const response = await apiClient.getJobs();
        const allJobs = response.jobs || [];

        const filteredJobs = allJobs.filter(job =>
            job.title.toLowerCase().includes(searchTerm) ||
            job.company.toLowerCase().includes(searchTerm) ||
            job.location.toLowerCase().includes(searchTerm) ||
            (job.description && job.description.toLowerCase().includes(searchTerm))
        );

        displayJobs(filteredJobs);
    } catch (error) {
        console.error('Eroare la search:', error);
    }
}

function filterByLocation(location) {
    document.getElementById("search-input").value = location;
    searchJobs();
}

// Evenimentul principal care ruleaza la incarcarea paginii
window.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await apiClient.getJobs();
        allJobsData = response.jobs || [];
        displayJobs(allJobsData);
    } catch (error) {
        console.error('Eroare la incarcare joburi:', error);
        displayJobs([]);
    }

    updateAuthButtons();

    const searchInput = document.getElementById("search-input");
    const searchButton = document.querySelector(".search-container button");

    if (searchInput) {
        searchInput.addEventListener("keypress", function(event) {
            if (event.key === "Enter") {
                event.preventDefault();
                searchJobs();
            }
        });
    }
    
    if (searchButton) {
        searchButton.onclick = searchJobs;
    }

    // Facem functia globala
    window.filterByLocation = filterByLocation;
});
