// ====== API CLIENT ======
const API_BASE = '/api';

const apiClient = {
    async request(endpoint, options = {}) {
        // Construieste URL - endpoint-ul e pasat fara .php
        const url = `${API_BASE}/${endpoint}`;
        
        console.log(`[API Request] ${options.method || 'GET'} ${url}`);
        
        const response = await fetch(url, {
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                ...options.headers,
            },
            ...options,
        });

        console.log(`[API Response] Status: ${response.status}`);
        
        const text = await response.text();
        console.log(`[API Response] Body: ${text.substring(0, 200)}`);

        if (!response.ok) {
            try {
                const error = JSON.parse(text);
                throw new Error(error.error || 'Request failed');
            } catch (e) {
                throw new Error(`API Error (${response.status}): ${text.substring(0, 100)}`);
            }
        }

        try {
            return JSON.parse(text);
        } catch (e) {
            console.error(`[API] Failed to parse JSON response: ${text}`);
            throw new Error(`Invalid JSON response: ${text.substring(0, 100)}`);
        }
    },

    // Auth
    login(username, password) {
        return this.request('auth', {
            method: 'POST',
            body: JSON.stringify({ username, password }),
        });
    },

    register(username, password, email) {
        return this.request('register', {
            method: 'POST',
            body: JSON.stringify({ username, password, email }),
        });
    },

    async checkSession() {
        const response = await this.request('auth', { method: 'GET' });
        return response;
    },

    logout() {
        return this.request('profile?logout=1', { method: 'POST' });
    },

    // Jobs
    getJobs() {
        return this.request('jobs', { method: 'GET' });
    },

    getJobById(id) {
        return this.request(`jobs?id=${id}`, { method: 'GET' });
    },

    createJob(jobData) {
        return this.request('jobs', {
            method: 'POST',
            body: JSON.stringify(jobData),
        });
    },

    getMyJobs() {
        return this.request('jobs?my-jobs=1', { method: 'GET' });
    },

    deleteJob(jobId) {
        return this.request('jobs', {
            method: 'DELETE',
            body: JSON.stringify({ id: jobId }),
        });
    },

    getJobApplicants(jobId) {
        return this.request(`jobs?applicants=${jobId}`, { method: 'GET' });
    },

    updateApplicantStatus(jobId, applicationId, status) {
        return this.request(`jobs?applicants=${jobId}`, {
            method: 'PUT',
            body: JSON.stringify({ application_id: applicationId, status }),
        });
    },

    // Messages
    getMessageUsers() {
        return this.request('messages?users=1', { method: 'GET' });
    },

    getConversation(withUser) {
        return this.request(`messages?with=${encodeURIComponent(withUser)}`, { method: 'GET' });
    },

    sendMessage(toUsername, message) {
        return this.request('messages', {
            method: 'POST',
            body: JSON.stringify({ to_username: toUsername, message }),
        });
    },

    // Applications
    getApplications() {
        return this.request('applications', { method: 'GET' });
    },

    applyForJob(jobId, coverLetter = '') {
        return this.request('applications', {
            method: 'POST',
            body: JSON.stringify({ job_id: jobId, cover_letter: coverLetter }),
        });
    },

    removeApplication(applicationId) {
        return this.request('applications', {
            method: 'DELETE',
            body: JSON.stringify({ application_id: applicationId }),
        });
    },

    // CVs
    uploadCV(file) {
        const formData = new FormData();
        formData.append('cv', file);

        return fetch(`${API_BASE}/cvs`, {
            method: 'POST',
            credentials: 'include',
            body: formData,
        }).then(r => r.json());
    },

    getCVs() {
        return this.request('cvs', { method: 'GET' });
    },

    deleteCV(cvId) {
        return this.request('cvs', {
            method: 'DELETE',
            body: JSON.stringify({ cv_id: cvId }),
        });
    },

    // Profile
    getProfile() {
        return this.request('profile', { method: 'GET' });
    },

    updateProfile(data) {
        return this.request('profile', {
            method: 'PUT',
            body: JSON.stringify(data),
        });
    },

    // Saved Jobs
    saveJob(jobId) {
        return this.request('saved-jobs', {
            method: 'POST',
            body: JSON.stringify({ job_id: jobId }),
        });
    },

    getSavedJobs() {
        return this.request('saved-jobs', { method: 'GET' });
    },

    removeSavedJob(jobId) {
        return this.request('saved-jobs', {
            method: 'DELETE',
            body: JSON.stringify({ job_id: jobId }),
        });
    },

    // Admin
    getUsers() {
        return this.request('admin', { method: 'GET' });
    },

    updateUserRole(userId, role) {
        return this.request('admin', {
            method: 'PUT',
            body: JSON.stringify({ user_id: userId, role }),
        });
    },

    deleteUser(userId) {
        return this.request('admin', {
            method: 'DELETE',
            body: JSON.stringify({ user_id: userId }),
        });
    },

    getAdminStats() {
        return this.request('admin?stats=1', { method: 'GET' });
    },
};
