// ====== MY JOBS PAGE ======

let currentJobId = null;
let userRole = null;

document.addEventListener('DOMContentLoaded', async () => {
    // Check session
    try {
        const session = await apiClient.checkSession();
        userRole = session.user.role;
    } catch (e) {
        window.location.href = 'login.html';
        return;
    }

    loadJobs();
});

async function loadJobs() {
    const container = document.getElementById('my-jobs-list');
    container.innerHTML = '<p class="loading">Se incarca joburile...</p>';

    try {
        let jobs = [];
        if (userRole === 'client') {
            const data = await apiClient.getMyJobs();
            jobs = data.jobs || [];
        } else if (userRole === 'admin') {
            const data = await apiClient.getJobs();
            jobs = data.jobs || [];
        }

        if (jobs.length === 0) {
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
                    <p style="color: #6b7280; font-size: 16px; margin-bottom: 20px;">Nu au fost gasite joburi</p>
                </div>
            `;
            return;
        }

        container.innerHTML = jobs.map(job => {
            let jobCard = `
                <div class="job-card-my">
                    <div class="job-info-my">
                        <div class="job-title-my">${escapeHtml(job.title)}</div>
                        <div class="job-meta-my">
                            <strong>${escapeHtml(job.company)}</strong> • 
                            ${escapeHtml(job.location)}
                        </div>
                        <div class="job-meta-my">
                            ${job.salary_min ? `Salariu: $${job.salary_min} - $${job.salary_max}` : 'Salariu negociabil'}
                        </div>
                        <div>
                            <span class="job-status-badge ${job.status === 'active' ? 'status-active' : 'status-closed'}">
                                ${job.status === 'active' ? 'Activ' : 'Inchis'}
                            </span>
                        </div>
                    </div>
                    <div class="job-actions-my">`;
            
            if (userRole === 'client') {
                jobCard += `
                        <div class="applicant-count">
                            ${job.application_count || 0} <br> candidati
                        </div>
                        <button class="btn-view-applicants" onclick="viewApplicants(${job.id}, '${escapeHtml(job.title).replace(/'/g, "\\'")}')">
                            Vezi Candidati
                        </button>`;
            } else if (userRole === 'admin') {
                jobCard += `
                        <div style="display: flex; gap: 10px;">
                            <button class="btn-small" style="background: #ef4444; color: white; cursor: pointer;" onclick="deleteJob(${job.id}, '${escapeHtml(job.title).replace(/'/g, "\\'")}')" title="Sterge job">
                                Sterge
                            </button>
                        </div>`;
            }
            
            jobCard += `
                    </div>
                </div>
            `;
            return jobCard;
        }).join('');

    } catch (error) {
        console.error('Eroare la incarcarea joburilor:', error);
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
                <p style="color: #ef4444;">Eroare la incarcarea joburilor: ${error.message}</p>
                <button onclick="loadJobs()" class="btn btn-primary" style="margin-top: 15px;">Incearca din nou</button>
            </div>
        `;
    }
}

async function deleteJob(jobId, jobTitle) {
    if (!confirm(`Esti sigur ca vrei sa stergi jobul "${jobTitle}"?`)) {
        return;
    }

    try {
        await apiClient.deleteJob(jobId);
        alert('✅ Job sters cu succes!');
        loadJobs();
    } catch (error) {
        alert('Eroare: ' + error.message);
    }
}

async function viewApplicants(jobId, jobTitle) {
    currentJobId = jobId;
    const modal = document.getElementById('applicants-modal');
    const applicantsList = document.getElementById('applicants-list');

    document.getElementById('job-title-modal').textContent = jobTitle;
    applicantsList.innerHTML = '<p class="loading">Se incarca candidatii...</p>';
    modal.classList.remove('hidden');

    try {
        const data = await apiClient.getJobApplicants(jobId);
        const applicants = data.applicants || [];

        if (applicants.length === 0) {
            applicantsList.innerHTML = '<p style="text-align: center; color: #6b7280;">Inca nu sunt candidati pentru acest job</p>';
            return;
        }

        applicantsList.innerHTML = applicants.map(app => `
            <div class="applicant-item">
                <div class="applicant-info">
                    <div class="applicant-name">${escapeHtml(app.full_name || app.username)}</div>
                    <div class="applicant-email">${escapeHtml(app.email)}</div>
                    ${app.cover_letter ? `<div class="applicant-email" style="margin-top: 6px; font-style: italic;">"${escapeHtml(app.cover_letter.substring(0, 60))}${app.cover_letter.length > 60 ? '...' : ''}"</div>` : ''}
                    <div class="applicant-date">Aplicat: ${new Date(app.applied_at).toLocaleDateString('ro-RO')} - Status: <strong class="${getStatusClass(app.app_status)}">${getStatusLabel(app.app_status)}</strong></div>
                </div>
                <div class="applicant-actions">
                    ${app.cv_file ? `<a href="/uploads/cvs/${app.cv_file}" class="btn-small" style="background: #dbeafe; color: #1e40af; text-decoration: none;" download>Download CV</a>` : '<span style="font-size: 12px; color: #9ca3af;">Fara CV</span>'}
                    <button class="btn-small btn-approve" onclick="updateStatus(${app.application_id}, 'accepted')">Accepta</button>
                    <button class="btn-small btn-reject" onclick="updateStatus(${app.application_id}, 'rejected')">Respinge</button>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Eroare la incarcarea candidatilor:', error);
        applicantsList.innerHTML = `<p style="text-align: center; color: #ef4444;">Eroare: ${error.message}</p>`;
    }
}

function getStatusLabel(status) {
    const labels = {
        'pending': 'In Asteptare',
        'accepted': 'Acceptat',
        'rejected': 'Respins'
    };
    return labels[status] || status;
}

function getStatusClass(status) {
    const classes = {
        'pending': 'status-pending',
        'accepted': 'status-accepted',
        'rejected': 'status-rejected'
    };
    return classes[status] || '';
}

async function updateStatus(applicationId, newStatus) {
    if (!currentJobId) return;

    try {
        await apiClient.updateApplicantStatus(currentJobId, applicationId, newStatus);
        alert('✅ Status actualizat!');
        viewApplicants(currentJobId, document.getElementById('job-title-modal').textContent);
    } catch (error) {
        alert('Eroare: ' + error.message);
    }
}

function closeApplicantsModal() {
    document.getElementById('applicants-modal').classList.add('hidden');
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}

document.addEventListener('click', (e) => {
    const modal = document.getElementById('applicants-modal');
    if (e.target === modal) {
        closeApplicantsModal();
    }
});
