let currentUser = null;
let currentRecipient = null;

document.addEventListener('DOMContentLoaded', async () => {
    try {
        const session = await apiClient.checkSession();
        if (!session.user) {
            window.location.href = 'login.html';
            return;
        }
        currentUser = session.user;
    } catch (e) {
        window.location.href = 'login.html';
        return;
    }

    await loadInbox();
    bindEvents();

    const params = new URLSearchParams(window.location.search);
    const preset = params.get('with');
    if (preset) {
        currentRecipient = preset;
        await loadConversation();
    } else {
        const first = getFirstInboxUser();
        if (first) {
            currentRecipient = first;
            await loadConversation();
        } else {
            const header = document.getElementById('conversation-header');
            header.textContent = 'Nu ai selectat un destinatar.';
        }
    }
});

function bindEvents() {
    const sendBtn = document.getElementById('send-message-btn');

    sendBtn.addEventListener('click', async () => {
        const body = document.getElementById('message-body').value.trim();
        if (!currentRecipient) {
            alert('Destinatar lipsa. Acceseaza pagina cu ?with=USERNAME.');
            return;
        }
        if (!body) {
            alert('Mesajul nu poate fi gol.');
            return;
        }

        try {
            await apiClient.sendMessage(currentRecipient, body);
            document.getElementById('message-body').value = '';
            await loadConversation();
        } catch (error) {
            alert('Eroare: ' + error.message);
        }
    });
}

let inboxCache = [];

function getFirstInboxUser() {
    return inboxCache.length ? inboxCache[0].username : null;
}

async function loadInbox() {
    const inboxList = document.getElementById('inbox-list');
    if (!inboxList) return;

    inboxList.innerHTML = '';

    try {
        const data = await apiClient.request('messages?inbox=1', { method: 'GET' });
        const inbox = data.inbox || [];
        inboxCache = inbox;

        if (!inbox.length) {
            inboxList.innerHTML = '<p class="message-meta">Nu ai conversatii inca.</p>';
            return;
        }

        inbox.forEach(user => {
            const item = document.createElement('button');
            item.className = 'inbox-item';
            item.textContent = user.full_name ? `${user.username} (${user.full_name})` : user.username;
            item.addEventListener('click', async () => {
                currentRecipient = user.username;
                highlightInbox(user.username);
                await loadConversation();
            });
            inboxList.appendChild(item);
        });
    } catch (error) {
        inboxList.innerHTML = '<p class="message-meta">Eroare la incarcare conversatii.</p>';
    }
}

function highlightInbox(username) {
    const items = document.querySelectorAll('.inbox-item');
    items.forEach(item => {
        item.classList.toggle('active', item.textContent.startsWith(username));
    });
}

async function loadConversation() {
    const list = document.getElementById('messages-list');
    const header = document.getElementById('conversation-header');

    list.innerHTML = '';

    if (!currentRecipient) {
        header.textContent = 'Alege un utilizator pentru a vedea conversatia.';
        const title = document.getElementById('conversation-title');
        if (title) {
            title.textContent = 'Conversatie';
        }
        return;
    }

    try {
        const data = await apiClient.getConversation(currentRecipient);
        header.textContent = `Conversatie cu ${data.with.username}`;
        const title = document.getElementById('conversation-title');
        if (title) {
            title.textContent = `Conversatie cu ${data.with.username}`;
        }
        highlightInbox(data.with.username);

        if (!data.messages.length) {
            list.innerHTML = '<p class="message-meta">Nu exista mesaje inca.</p>';
            return;
        }

        data.messages.forEach(msg => {
            const bubble = document.createElement('div');
            const isMe = msg.sender_id === currentUser.id;
            bubble.className = `message-bubble ${isMe ? 'message-me' : 'message-them'}`;
            bubble.innerHTML = `
                <div>${escapeHtml(msg.body)}</div>
                <div class="message-meta">${isMe ? 'Tu' : msg.sender_username} • ${new Date(msg.created_at).toLocaleString('ro-RO')}</div>
            `;
            list.appendChild(bubble);
        });

        list.scrollTop = list.scrollHeight;
    } catch (error) {
        console.error('Eroare la incarcare conversatie:', error);
        header.textContent = 'Eroare la incarcare conversatie.';
    }
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}
