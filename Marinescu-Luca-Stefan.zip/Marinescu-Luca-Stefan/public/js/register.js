﻿// Logica specifica pentru register.html
window.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById("register-form");

    if (registerForm) {
        registerForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value;
            const confirmPassword = document.getElementById("confirm-password").value;
            const email = "user@example.com";

            if (password !== confirmPassword) {
                alert("❌ Parolele nu se potrivesc!");
                return;
            }

            if (username.length < 3) {
                alert("⚠️ Username trebuie sa aiba minim 3 caractere.");
                return;
            }

            if (password.length < 6) {
                alert("⚠️ Parola trebuie sa aiba minim 6 caractere.");
                return;
            }

            try {
                const response = await apiClient.register(username, password, email);
                if (response.success) {
                    alert("✅ Cont creat cu succes! Acum poti sa te loghezi.");
                    window.location.href = "login.html";
                }
            } catch (error) {
                alert("❌ " + error.message);
            }
        });
    }
});
