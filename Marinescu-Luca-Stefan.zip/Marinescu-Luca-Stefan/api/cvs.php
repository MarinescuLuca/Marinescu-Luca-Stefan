<?php
require_once __DIR__ . '/config.php';

// ====== UPLOAD CV ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireLogin();

    if (!isset($_FILES['cv']) || $_FILES['cv']['error'] !== UPLOAD_ERR_OK) {
        respondJSON(['error' => 'Fisier CV necesar'], 400);
    }

    $file = $_FILES['cv'];
    $userId = $_SESSION['user']['id'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    // Validation
    $allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!in_array($file['type'], $allowedTypes)) {
        respondJSON(['error' => 'Doar PDF si Word sunt acceptate'], 400);
    }

    if ($file['size'] > $maxSize) {
        respondJSON(['error' => 'Fisierul nu trebuie sa depaseasca 5MB'], 400);
    }

    try {
        $cvDir = __DIR__ . '/../uploads/cv/';
        if (!is_dir($cvDir)) {
            mkdir($cvDir, 0755, true);
        }

        $fileName = 'cv_' . $userId . '_' . time() . '_' . basename($file['name']);
        $filePath = $cvDir . $fileName;

        if (!move_uploaded_file($file['tmp_name'], $filePath)) {
            respondJSON(['error' => 'Eroare la upload fisier'], 500);
        }

        $stmt = $pdo->prepare('INSERT INTO cvs (user_id, file_name, file_path, file_size) VALUES (?, ?, ?, ?)');
        $stmt->execute([$userId, $fileName, '/uploads/cv/' . $fileName, $file['size']]);

        respondJSON(['success' => true, 'message' => 'CV incarcat cu succes', 'file_name' => $fileName]);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
    }
}

// ====== GET USER CVS ======
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    requireLogin();

    try {
        $userId = $_SESSION['user']['id'];
        $stmt = $pdo->prepare('SELECT id, file_name, file_path, file_size, uploaded_at FROM cvs WHERE user_id = ? ORDER BY uploaded_at DESC');
        $stmt->execute([$userId]);
        $cvs = $stmt->fetchAll();
        respondJSON(['cvs' => $cvs]);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
    }
}

// ====== DELETE CV ======
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    requireLogin();

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['cv_id'])) {
        respondJSON(['error' => 'cv_id este obligatoriu'], 400);
    }

    $cvId = (int)$input['cv_id'];
    $userId = $_SESSION['user']['id'];

    try {
        $stmt = $pdo->prepare('SELECT file_path FROM cvs WHERE id = ? AND user_id = ?');
        $stmt->execute([$cvId, $userId]);
        $cv = $stmt->fetch();

        if (!$cv) {
            respondJSON(['error' => 'CV nu a fost gasit'], 404);
        }

        // Delete file
        $filePath = __DIR__ . '/..' . $cv['file_path'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete from database
        $stmt = $pdo->prepare('DELETE FROM cvs WHERE id = ? AND user_id = ?');
        $stmt->execute([$cvId, $userId]);

        respondJSON(['success' => true, 'message' => 'CV sters cu succes']);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la stergere'], 500);
    }
}
?>
