<?php
// Router simplu pentru API
require_once __DIR__ . '/config.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = str_replace('/api/', '', $path);
$path = trim($path, '/');

// Extrage endpointul (inainte de ?)
$endpoint = explode('?', $path)[0];

// Mapare endpointuri la fisiere
$routes = [
    'auth' => 'auth.php',
    'register' => 'register.php',
    'jobs' => 'jobs.php',
    'applications' => 'applications.php',
    'cvs' => 'cvs.php',
    'messages' => 'messages.php',
    'profile' => 'profile.php',
    'saved-jobs' => 'saved-jobs.php',
    'admin' => 'admin.php',
];

if (isset($routes[$endpoint])) {
    include $routes[$endpoint];
} else {
    respondJSON(['error' => 'Endpoint not found'], 404);
}
?>
