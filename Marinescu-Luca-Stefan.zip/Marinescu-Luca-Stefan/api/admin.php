<?php
require_once __DIR__ . '/config.php';

// ====== REQUIRE ADMIN ======
if (!isLoggedIn() || $_SESSION['user']['role'] !== 'admin') {
    respondJSON(['error' => 'Acces interzis - doar admin'], 403);
    exit;
}

// ====== GET STATISTICS ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['stats'])) {
    try {
        $stmt = $pdo->query('SELECT COUNT(*) as total FROM users');
        $totalUsers = $stmt->fetch()['total'];

        $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'admin'");
        $adminCount = $stmt->fetch()['total'];

        $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'client'");
        $clientCount = $stmt->fetch()['total'];

        $stmt = $pdo->query('SELECT COUNT(*) as total FROM jobs WHERE status = "active"');
        $activeJobs = $stmt->fetch()['total'];

        $stmt = $pdo->query('SELECT COUNT(*) as total FROM applications');
        $totalApplications = $stmt->fetch()['total'];

        respondJSON([
            'stats' => [
                'total_users' => $totalUsers,
                'admins' => $adminCount,
                'clients' => $clientCount,
                'active_jobs' => $activeJobs,
                'total_applications' => $totalApplications
            ]
        ]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== GET ALL USERS ======
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->query('SELECT id, username, email, full_name, role, created_at FROM users ORDER BY created_at DESC');
        $users = $stmt->fetchAll();
        respondJSON(['users' => $users]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== UPDATE USER ROLE ======
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['user_id']) || !isset($input['role'])) {
        respondJSON(['error' => 'user_id si role sunt obligatorii'], 400);
        exit;
    }

    $userId = (int)$input['user_id'];
    $role = $input['role'];

    if (!in_array($role, ['admin', 'client'])) {
        respondJSON(['error' => 'Role invalid. Acceptate: admin, client'], 400);
        exit;
    }

    // Prevent self-demotion
    if ($userId === $_SESSION['user']['id'] && $role !== 'admin') {
        respondJSON(['error' => 'Nu poti-ti modifica propriul role'], 400);
        exit;
    }

    try {
        $stmt = $pdo->prepare('UPDATE users SET role = ? WHERE id = ?');
        $stmt->execute([$role, $userId]);

        respondJSON(['success' => true, 'message' => "User role schimbat la: $role"]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la update'], 500);
        exit;
    }
}

// ====== DELETE USER (ADMIN ONLY) ======
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['user_id'])) {
        respondJSON(['error' => 'user_id este obligatoriu'], 400);
        exit;
    }

    $userId = (int)$input['user_id'];

    // Prevent self-deletion
    if ($userId === $_SESSION['user']['id']) {
        respondJSON(['error' => 'Nu poti sterge propriul cont'], 400);
        exit;
    }

    try {
        // Delete user's applications
        $stmt = $pdo->prepare('DELETE FROM applications WHERE user_id = ?');
        $stmt->execute([$userId]);

        // Delete user's CVs
        $stmt = $pdo->prepare('DELETE FROM cvs WHERE user_id = ?');
        $stmt->execute([$userId]);

        // Delete user's saved jobs
        $stmt = $pdo->prepare('DELETE FROM saved_jobs WHERE user_id = ?');
        $stmt->execute([$userId]);

        // Delete user
        $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
        $stmt->execute([$userId]);

        respondJSON(['success' => true, 'message' => 'User sters cu succes']);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la stergere'], 500);
        exit;
    }
}
?>
