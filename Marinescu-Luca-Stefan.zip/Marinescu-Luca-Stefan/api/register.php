<?php
require_once __DIR__ . '/config.php';

// ====== REGISTER USER ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['username']) || !isset($input['password'])) {
        respondJSON(['error' => 'Username si parola sunt obligatorii'], 400);
    }

    $username = trim($input['username']);
    $password = $input['password'];
    $email = $input['email'] ?? null;

    // Validation
    if (strlen($username) < 3) {
        respondJSON(['error' => 'Username trebuie sa aiba minim 3 caractere'], 400);
    }
    if (strlen($password) < 6) {
        respondJSON(['error' => 'Parola trebuie sa aiba minim 6 caractere'], 400);
    }

    try {
        // Check if username already exists
        $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            respondJSON(['error' => 'Username deja exista'], 400);
        }

        // Insert new user with role='client'
        $hashedPassword = hashPassword($password);
        $stmt = $pdo->prepare('INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, "client")');
        $stmt->execute([$username, $hashedPassword, $email]);

        respondJSON(['success' => true, 'message' => 'Cont creat cu succes']);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la crearea contului'], 500);
    }
}
?>
