<?php
require_once __DIR__ . '/config.php';

// ====== SAVE JOB ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireLogin();

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['job_id'])) {
        respondJSON(['error' => 'job_id este obligatoriu'], 400);
    }

    $jobId = (int)$input['job_id'];
    $userId = $_SESSION['user']['id'];

    try {
        // Check if already saved
        $stmt = $pdo->prepare('SELECT id FROM saved_jobs WHERE user_id = ? AND job_id = ? LIMIT 1');
        $stmt->execute([$userId, $jobId]);
        if ($stmt->fetch()) {
            respondJSON(['error' => 'Job deja salvat'], 400);
        }

        $stmt = $pdo->prepare('INSERT INTO saved_jobs (user_id, job_id) VALUES (?, ?)');
        $stmt->execute([$userId, $jobId]);

        respondJSON(['success' => true, 'message' => 'Job salvat']);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
    }
}

// ====== GET SAVED JOBS ======
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    requireLogin();

    try {
        $userId = $_SESSION['user']['id'];
        $stmt = $pdo->prepare('
            SELECT j.id, j.title, j.company, j.location, j.salary_min, j.salary_max, j.created_at
            FROM saved_jobs s
            JOIN jobs j ON s.job_id = j.id
            WHERE s.user_id = ?
            ORDER BY s.saved_at DESC
        ');
        $stmt->execute([$userId]);
        $jobs = $stmt->fetchAll();
        respondJSON(['saved_jobs' => $jobs]);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
    }
}

// ====== REMOVE SAVED JOB ======
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    requireLogin();

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['job_id'])) {
        respondJSON(['error' => 'job_id este obligatoriu'], 400);
    }

    $jobId = (int)$input['job_id'];
    $userId = $_SESSION['user']['id'];

    try {
        $stmt = $pdo->prepare('DELETE FROM saved_jobs WHERE user_id = ? AND job_id = ?');
        $stmt->execute([$userId, $jobId]);

        respondJSON(['success' => true, 'message' => 'Job sters din salvari']);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la stergere'], 500);
    }
}
?>
