<?php
require_once __DIR__ . '/config.php';

if (!isLoggedIn()) {
    respondJSON(['error' => 'Trebuie sa fii autentificat'], 403);
    exit;
}

$userId = $_SESSION['user']['id'];

// ====== ENSURE TABLE EXISTS ======
try {
    $pdo->exec('
        CREATE TABLE IF NOT EXISTS messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            body TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            read_at TIMESTAMP NULL,
            INDEX idx_sender (sender_id),
            INDEX idx_receiver (receiver_id),
            INDEX idx_created (created_at),
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ');
} catch (PDOException $e) {
    respondJSON(['error' => 'Eroare la initializare mesaje'], 500);
    exit;
}

// ====== LIST USERS FOR MESSAGING ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['users'])) {
    try {
        $stmt = $pdo->prepare('SELECT id, username, full_name FROM users WHERE id != ? ORDER BY username ASC');
        $stmt->execute([$userId]);
        $users = $stmt->fetchAll();
        respondJSON(['users' => $users]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== INBOX (CONVERSATION PARTNERS) ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['inbox'])) {
    try {
        $stmt = $pdo->prepare('
            SELECT u.id, u.username, u.full_name, MAX(m.created_at) AS last_message
            FROM messages m
            JOIN users u ON u.id = CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END
            WHERE m.sender_id = ? OR m.receiver_id = ?
            GROUP BY u.id, u.username, u.full_name
            ORDER BY last_message DESC
        ');
        $stmt->execute([$userId, $userId, $userId]);
        $inbox = $stmt->fetchAll();
        respondJSON(['inbox' => $inbox]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== GET CONVERSATION ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['with'])) {
    $with = trim($_GET['with']);

    try {
        if (is_numeric($with)) {
            $stmt = $pdo->prepare('SELECT id, username FROM users WHERE id = ? LIMIT 1');
            $stmt->execute([(int)$with]);
        } else {
            $stmt = $pdo->prepare('SELECT id, username FROM users WHERE username = ? LIMIT 1');
            $stmt->execute([$with]);
        }
        $other = $stmt->fetch();

        if (!$other) {
            respondJSON(['error' => 'Utilizatorul nu a fost gasit'], 404);
            exit;
        }

        $stmt = $pdo->prepare('
            SELECT m.id, m.sender_id, m.receiver_id, m.body, m.created_at,
                   su.username AS sender_username,
                   ru.username AS receiver_username
            FROM messages m
            JOIN users su ON su.id = m.sender_id
            JOIN users ru ON ru.id = m.receiver_id
            WHERE (m.sender_id = ? AND m.receiver_id = ?)
               OR (m.sender_id = ? AND m.receiver_id = ?)
            ORDER BY m.created_at ASC
        ');
        $stmt->execute([$userId, $other['id'], $other['id'], $userId]);
        $messages = $stmt->fetchAll();

        respondJSON([
            'with' => $other,
            'messages' => $messages
        ]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== SEND MESSAGE ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input || empty($input['message']) || (!isset($input['to_username']) && !isset($input['to_user_id']))) {
        respondJSON(['error' => 'Destinatar si mesaj obligatorii'], 400);
        exit;
    }

    $message = trim($input['message']);
    if ($message === '') {
        respondJSON(['error' => 'Mesajul nu poate fi gol'], 400);
        exit;
    }

    try {
        if (isset($input['to_user_id'])) {
            $stmt = $pdo->prepare('SELECT id, username FROM users WHERE id = ? LIMIT 1');
            $stmt->execute([(int)$input['to_user_id']]);
        } else {
            $stmt = $pdo->prepare('SELECT id, username FROM users WHERE username = ? LIMIT 1');
            $stmt->execute([trim($input['to_username'])]);
        }
        $receiver = $stmt->fetch();

        if (!$receiver) {
            respondJSON(['error' => 'Destinatar invalid'], 404);
            exit;
        }

        if ((int)$receiver['id'] === (int)$userId) {
            respondJSON(['error' => 'Nu poti trimite mesaj catre tine'], 400);
            exit;
        }

        $stmt = $pdo->prepare('INSERT INTO messages (sender_id, receiver_id, body) VALUES (?, ?, ?)');
        $stmt->execute([$userId, $receiver['id'], $message]);

        respondJSON(['success' => true, 'message' => 'Mesaj trimis', 'id' => $pdo->lastInsertId()]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la trimitere mesaj'], 500);
        exit;
    }
}

respondJSON(['error' => 'Endpoint invalid'], 404);
exit;
?>
