<?php
require_once __DIR__ . '/config.php';

// ====== HANDLE LOGIN ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['username']) || !isset($input['password'])) {
        respondJSON(['error' => 'Username si parola sunt obligatorii'], 400);
    }

    $username = $input['username'];
    $password = $input['password'];

    try {
        $stmt = $pdo->prepare('SELECT id, username, email, password, role FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if (!$user || !verifyPassword($password, $user['password'])) {
            respondJSON(['error' => 'Username sau parola incorecte'], 401);
        }

        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'] ?? null,
            'role' => $user['role'] ?? 'client'
        ];

        respondJSON(['success' => true, 'user' => $_SESSION['user']]);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
    }
}

// ====== HANDLE GET (CHECK SESSION) ======
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isLoggedIn()) {
        respondJSON(['user' => $_SESSION['user']]);
    } else {
        respondJSON(['user' => null]);
    }
}
?>
