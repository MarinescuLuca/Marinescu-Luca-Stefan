<?php
require_once __DIR__ . '/config.php';

// ====== GET USER PROFILE ======
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    requireLogin();

    try {
        $userId = $_SESSION['user']['id'];
        
        // Get user info
        $stmt = $pdo->prepare('SELECT id, username, email, full_name, role, created_at FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        // Get application count
        $stmt = $pdo->prepare('SELECT COUNT(*) as count FROM applications WHERE user_id = ?');
        $stmt->execute([$userId]);
        $appCount = $stmt->fetch()['count'];

        // Get CV count
        $stmt = $pdo->prepare('SELECT COUNT(*) as count FROM cvs WHERE user_id = ?');
        $stmt->execute([$userId]);
        $cvCount = $stmt->fetch()['count'];

        respondJSON([
            'user' => $user,
            'stats' => [
                'applications' => $appCount,
                'cvs' => $cvCount
            ]
        ]);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
    }
}

// ====== UPDATE USER PROFILE ======
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    requireLogin();

    $input = json_decode(file_get_contents('php://input'), true);
    $userId = $_SESSION['user']['id'];

    try {
        $updates = [];
        $params = [];

        if (isset($input['email'])) {
            $updates[] = 'email = ?';
            $params[] = $input['email'];
        }

        if (isset($input['full_name'])) {
            $updates[] = 'full_name = ?';
            $params[] = $input['full_name'];
        }

        if (empty($updates)) {
            respondJSON(['error' => 'Nu a fost trimis nimic de updatat'], 400);
        }

        $params[] = $userId;
        $sql = 'UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = ?';
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        respondJSON(['success' => true, 'message' => 'Profil updatat cu succes']);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la update profil'], 500);
    }
}

// ====== LOGOUT ======
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['logout'])) {
    session_destroy();
    respondJSON(['success' => true, 'message' => 'Deconectat cu succes']);
}
?>
