<?php
require_once __DIR__ . '/config.php';

// ====== GET ALL APPLICATIONS ======
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    requireLogin();

    try {
        $userId = $_SESSION['user']['id'];
        $stmt = $pdo->prepare('
            SELECT a.id, a.user_id, a.job_id, a.status, a.cover_letter, a.applied_at,
                   j.title, j.company, j.location
            FROM applications a
            JOIN jobs j ON a.job_id = j.id
            WHERE a.user_id = ?
            ORDER BY a.applied_at DESC
        ');
        $stmt->execute([$userId]);
        $applications = $stmt->fetchAll();
        respondJSON(['applications' => $applications]);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
    }
}

// ====== APPLY FOR JOB ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireLogin();

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['job_id'])) {
        respondJSON(['error' => 'job_id este obligatoriu'], 400);
    }

    $jobId = (int)$input['job_id'];
    $userId = $_SESSION['user']['id'];
    $coverLetter = $input['cover_letter'] ?? '';

    try {
        // Check if user already applied
        $stmt = $pdo->prepare('SELECT id FROM applications WHERE user_id = ? AND job_id = ? LIMIT 1');
        $stmt->execute([$userId, $jobId]);
        if ($stmt->fetch()) {
            respondJSON(['error' => 'Ai aplicat deja la acest job'], 400);
        }

        // Insert application
        $stmt = $pdo->prepare('INSERT INTO applications (user_id, job_id, cover_letter, status) VALUES (?, ?, ?, "pending")');
        $stmt->execute([$userId, $jobId, $coverLetter]);

        respondJSON(['success' => true, 'message' => 'Aplicatie trimisa cu succes']);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la aplicare job'], 500);
    }
}

// ====== REMOVE APPLICATION ======
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    requireLogin();

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['application_id'])) {
        respondJSON(['error' => 'application_id este obligatoriu'], 400);
    }

    $appId = (int)$input['application_id'];
    $userId = $_SESSION['user']['id'];

    try {
        $stmt = $pdo->prepare('DELETE FROM applications WHERE id = ? AND user_id = ?');
        $stmt->execute([$appId, $userId]);

        if ($stmt->rowCount() === 0) {
            respondJSON(['error' => 'Aplicatie nu a fost gasita'], 404);
        }

        respondJSON(['success' => true, 'message' => 'Aplicatie retractata']);
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la retractare'], 500);
    }
}
?>
