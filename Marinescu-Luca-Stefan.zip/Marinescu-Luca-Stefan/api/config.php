<?php
// ====== DATABASE CONFIG ======
define('DB_HOST', 'db');
define('DB_USER', 'user');
define('DB_PASSWORD', 'password');
define('DB_NAME', 'jobfinder_db');

// ====== CONNECT TO DATABASE ======
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASSWORD,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// ====== SESSION CONFIGURATION ======
ini_set('session.save_path', '/var/lib/php/sessions');
ini_set('session.gc_maxlifetime', 3600);
ini_set('session.cookie_httponly', 0);
ini_set('session.cookie_samesite', 'Lax');
session_start();

// ====== HELPER FUNCTIONS ======
function respondJSON($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function getUser() {
    return $_SESSION['user'] ?? null;
}

function isLoggedIn() {
    return isset($_SESSION['user']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        respondJSON(['error' => 'Trebuie sa fii autentificat'], 401);
    }
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// ====== ALLOW CORS ======
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
?>
