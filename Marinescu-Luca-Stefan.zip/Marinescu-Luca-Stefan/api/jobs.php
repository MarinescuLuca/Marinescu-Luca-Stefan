<?php
require_once __DIR__ . '/config.php';

// ====== GET ALL JOBS ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['id']) && !isset($_GET['my-jobs']) && !isset($_GET['applicants'])) {
    try {
        $stmt = $pdo->query('SELECT id, title, company, location, address, phone, image, description, salary_min, salary_max, job_type, created_at FROM jobs WHERE status = "active" ORDER BY created_at DESC');
        $jobs = $stmt->fetchAll();
        respondJSON(['jobs' => $jobs]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== CREATE NEW JOB ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Doar clientii pot adauga joburi
    requireLogin();
    
    if ($_SESSION['user']['role'] !== 'client') {
        respondJSON(['error' => 'Doar clientii pot adauga joburi'], 403);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['title']) || !isset($input['company']) || !isset($input['location'])) {
        respondJSON(['error' => 'Camp obligatoriu lipsa'], 400);
        exit;
    }

    $title = trim($input['title']);
    $company = trim($input['company']);
    $location = trim($input['location']);
    $address = trim($input['address'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $image = trim($input['image'] ?? '');
    $description = trim($input['description'] ?? '');
    $salary_min = $input['salary_min'] ?? null;
    $salary_max = $input['salary_max'] ?? null;
    $job_type = $input['job_type'] ?? 'Full-time';
    $user_id = $_SESSION['user']['id'];
    $username = $_SESSION['user']['username'];

    try {
        $stmt = $pdo->prepare('
            INSERT INTO jobs (title, company, location, address, phone, image, description, salary_min, salary_max, job_type, added_by, user_id, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active")
        ');
        
        $stmt->execute([
            $title, $company, $location, $address, $phone, $image, $description,
            $salary_min, $salary_max, $job_type, $username, $user_id
        ]);

        respondJSON(['success' => true, 'message' => 'Job adaugat cu succes', 'id' => $pdo->lastInsertId()]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la adaugare job'], 500);
        exit;
    }
}

// ====== GET JOB BY ID ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    try {
        $stmt = $pdo->prepare('
            SELECT j.*, u.username AS creator_username, u.full_name AS creator_name
            FROM jobs j
            LEFT JOIN users u ON u.id = j.user_id
            WHERE j.id = ?
            LIMIT 1
        ');
        $stmt->execute([$id]);
        $job = $stmt->fetch();

        if (!$job) {
            respondJSON(['error' => 'Job nu a fost gasit'], 404);
            exit;
        }

        respondJSON(['job' => $job]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== GET USER'S JOBS ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['my-jobs'])) {
    requireLogin();

    try {
        $stmt = $pdo->prepare('
            SELECT id, title, company, location, image, salary_min, salary_max, job_type, created_at, status,
                   (SELECT COUNT(*) FROM applications WHERE job_id = jobs.id) as application_count
            FROM jobs
            WHERE user_id = ?
            ORDER BY created_at DESC
        ');
        $stmt->execute([$_SESSION['user']['id']]);
        $jobs = $stmt->fetchAll();

        respondJSON(['jobs' => $jobs]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== GET APPLICANTS FOR A JOB ======
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['applicants'])) {
    $job_id = (int)$_GET['applicants'];
    requireLogin();

    try {
        // Check if user owns this job
        $check = $pdo->prepare('SELECT user_id FROM jobs WHERE id = ?');
        $check->execute([$job_id]);
        $job = $check->fetch();

        if (!$job || $job['user_id'] != $_SESSION['user']['id']) {
            respondJSON(['error' => 'Acces interzis'], 403);
            exit;
        }

        $stmt = $pdo->prepare('
            SELECT 
                u.id, u.username, u.email, u.full_name,
                a.id as application_id, a.status as app_status, a.cover_letter, a.applied_at,
                (SELECT file_name FROM cvs WHERE user_id = u.id ORDER BY uploaded_at DESC LIMIT 1) as cv_file
            FROM applications a
            JOIN users u ON a.user_id = u.id
            WHERE a.job_id = ?
            ORDER BY a.applied_at DESC
        ');
        $stmt->execute([$job_id]);
        $applicants = $stmt->fetchAll();

        respondJSON(['applicants' => $applicants]);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare baza de date'], 500);
        exit;
    }
}

// ====== UPDATE APPLICATION STATUS ======
if ($_SERVER['REQUEST_METHOD'] === 'PUT' && isset($_GET['applicants'])) {
    requireLogin();

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['application_id']) || !isset($input['status'])) {
        respondJSON(['error' => 'application_id si status sunt obligatorii'], 400);
        exit;
    }

    $appId = (int)$input['application_id'];
    $newStatus = $input['status'];
    $jobId = (int)$_GET['applicants'];

    if (!in_array($newStatus, ['pending', 'accepted', 'rejected'])) {
        respondJSON(['error' => 'Status invalid'], 400);
        exit;
    }

    try {
        // Check if user owns this job
        $check = $pdo->prepare('SELECT user_id FROM jobs WHERE id = ?');
        $check->execute([$jobId]);
        $job = $check->fetch();

        if (!$job || $job['user_id'] != $_SESSION['user']['id']) {
            respondJSON(['error' => 'Acces interzis'], 403);
            exit;
        }

        // Update application status
        $stmt = $pdo->prepare('
            UPDATE applications 
            SET status = ? 
            WHERE id = ? AND job_id = ?
        ');
        $stmt->execute([$newStatus, $appId, $jobId]);

        if ($stmt->rowCount() === 0) {
            respondJSON(['error' => 'Aplicatie nu a fost gasita'], 404);
            exit;
        }

        respondJSON(['success' => true, 'message' => 'Status actualizat']);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la actualizare status'], 500);
        exit;
    }
}

// ====== DELETE JOB (ADMIN ONLY) ======
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    requireLogin();

    if ($_SESSION['user']['role'] !== 'admin') {
        respondJSON(['error' => 'Doar adminii pot sterge joburi'], 403);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input || !isset($input['id'])) {
        respondJSON(['error' => 'ID job lipsa'], 400);
        exit;
    }

    $jobId = (int)$input['id'];

    try {
        $stmt = $pdo->prepare('DELETE FROM jobs WHERE id = ?');
        $stmt->execute([$jobId]);

        if ($stmt->rowCount() === 0) {
            respondJSON(['error' => 'Job nu a fost gasit'], 404);
            exit;
        }

        respondJSON(['success' => true, 'message' => 'Job sters cu succes']);
        exit;
    } catch (PDOException $e) {
        respondJSON(['error' => 'Eroare la stergere job'], 500);
        exit;
    }
}
?>
