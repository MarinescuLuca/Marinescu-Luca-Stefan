-- ====== DATABASE SETUP ======
CREATE DATABASE IF NOT EXISTS jobfinder_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE jobfinder_db;

-- ====== TABEL UTILIZATORI ======
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    full_name VARCHAR(100),
    role ENUM('admin', 'client') DEFAULT 'client',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====== TABEL JOBURI ======
CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    address VARCHAR(200),
    phone VARCHAR(20),
    image VARCHAR(100),
    description TEXT,
    salary_min DECIMAL(10, 2),
    salary_max DECIMAL(10, 2),
    job_type ENUM('Full-time', 'Part-time', 'Contract', 'Internship') DEFAULT 'Full-time',
    added_by VARCHAR(50),
    user_id INT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_location (location),
    INDEX idx_company (company),
    INDEX idx_status (status),
    INDEX idx_user_id (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====== TABEL CV-URI ======
CREATE TABLE IF NOT EXISTS cvs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500),
    file_size INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====== TABEL APLICATII LA JOBURI ======
CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    job_id INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'withdrawn') DEFAULT 'pending',
    cover_letter TEXT,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    UNIQUE KEY unique_application (user_id, job_id),
    INDEX idx_status (status),
    INDEX idx_user_id (user_id),
    INDEX idx_job_id (job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====== TABEL SALVARI FAVORITE (WISHLIST) ======
CREATE TABLE IF NOT EXISTS saved_jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    job_id INT NOT NULL,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    UNIQUE KEY unique_saved (user_id, job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====== TABEL MESAJE ======
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL,
    INDEX idx_sender (sender_id),
    INDEX idx_receiver (receiver_id),
    INDEX idx_created (created_at),
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====== TABEL COMPANII ======
CREATE TABLE IF NOT EXISTS companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    description TEXT,
    website VARCHAR(255),
    email VARCHAR(100),
    phone VARCHAR(20),
    logo_url VARCHAR(255),
    industry VARCHAR(100),
    founded_year INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====== INSERARE DATE INITIALE - UTILIZATORI ======
INSERT INTO users (username, email, full_name, password, role) VALUES 
('admin', 'admin@jobfinder.com', 'Administrator', '$2y$10$A.7Dod9mgtnV6bCRvpSHVerm7aDsxNNz.lEljQKf4HSBy8GVFaTVe', 'admin');

-- ====== INSERARE DATE INITIALE - COMPANII ======
INSERT INTO companies (name, description, website, email, industry, founded_year) VALUES 
('WebDev Solutions', 'Companie specialista in dezvoltare web si aplicatii mobile', 'www.webdev.ro', 'info@webdev.ro', 'IT & Software', 2015),
('Mega Retail', 'Lantul de magazine cu cea mai larga retea din Romania', 'www.megaretail.ro', 'careers@megaretail.ro', 'Retail', 2005),
('FastDelivery', 'Servicii de logistica si livrare rapida', 'www.fastdelivery.ro', 'jobs@fastdelivery.ro', 'Logistics', 2018),
('ElectroServ', 'Specialist in instalatii electrice industriale', 'www.electroserv.ro', 'contact@electroserv.ro', 'Construction', 2010),
('Creative Studio', 'Agentie de design si publicitate', 'www.creativestudio.ro', 'work@creativestudio.ro', 'Design & Marketing', 2012);

-- ====== INSERARE DATE INITIALE - JOBURI ======
INSERT INTO jobs (title, company, location, address, phone, image, description, salary_min, salary_max, job_type, status) VALUES 
('Programator Front-End', 'WebDev Solutions', 'Bucuresti', 'B-dul Unirii Nr. 5', '0745 123 456', 'programator.jpg', 'Cautam un front-end developer pasionat de React si UI modern. Cerinte: 3+ ani experienta, cunostinte HTML/CSS/JavaScript.', 4000.00, 6000.00, 'Full-time', 'active'),
('Vanzator Magazin', 'Mega Retail', 'Cluj-Napoca', 'Str. Principala 10', '0750 987 654', 'vanzator.jpg', 'Angajam vanzatori cu experienta in retail alimentar. Responsabilitati: deservire clienti, reaprovizionare, casa.', 2000.00, 2500.00, 'Full-time', 'active'),
('Sofer Livrari', 'FastDelivery', 'Iasi', 'Calea Chisinaului 3', '0733 444 555', 'livrari.jpg', 'Cautam soferi responsabili pentru livrari rapide in oras. Permis categoria B obligatoriu, vehicul asigurat.', 2500.00, 3200.00, 'Full-time', 'active'),
('Electrician', 'ElectroServ', 'Constanta', 'Bd. Tomis 200', '0760 111 222', 'electrician.jpg', 'Post disponibil pentru electrician cu experienta in instalatii industriale. Certificari necesare.', 3500.00, 5000.00, 'Full-time', 'active'),
('Designer Grafic', 'Creative Studio', 'Timisoara', 'Piata Victoriei 1', '0720 777 888', 'design.jpg', 'Cautam un designer creativ pentru proiecte publicitare. Cunostinte: Photoshop, Illustrator, Adobe XD.', 3000.00, 4500.00, 'Full-time', 'active'),
('Data Analyst', 'WebDev Solutions', 'Bucuresti', 'B-dul Unirii Nr. 5', '0745 123 456', 'analyst.jpg', 'Analiza datelor pentru proiecte IT. Cunostinte SQL, Python, Excel avansat.', 3500.00, 5500.00, 'Full-time', 'active'),
('Receptionist', 'Mega Retail', 'Bucuresti', 'Piata Presei Libere 1', '0721 555 666', 'receptionist.jpg', 'Administrator de receptie pentru sediul central. Comunicare buna, limba engleza.', 2000.00, 2300.00, 'Full-time', 'active'),
('Social Media Manager', 'Creative Studio', 'Iasi', 'Str. Andrei Pippidi 5', '0722 777 888', 'social.jpg', 'Gestionare conturi social media, creere content, community management.', 2800.00, 4000.00, 'Full-time', 'active');

-- ====== CREARE INDECSI PENTRU PERFORMANTA ======
CREATE INDEX idx_jobs_created ON jobs(created_at);
CREATE INDEX idx_applications_created ON applications(applied_at);
CREATE INDEX idx_cvs_created ON cvs(uploaded_at);

-- ====== CREARE VIEWS PENTRU FACILITATE ======
CREATE OR REPLACE VIEW active_jobs AS
SELECT id, title, company, location, salary_min, salary_max, job_type, created_at
FROM jobs
WHERE status = 'active'
ORDER BY created_at DESC;

CREATE OR REPLACE VIEW user_applications AS
SELECT 
    u.username,
    j.title as job_title,
    j.company,
    a.status,
    a.applied_at
FROM applications a
JOIN users u ON a.user_id = u.id
JOIN jobs j ON a.job_id = j.id
ORDER BY a.applied_at DESC;